#!/bin/sh

topojson -o sverige.json Kommer_SCB_geojson/sverige.geojson -p
