Boilerplate for a map of Sweden, rendered with D3 and TopoJSON. The original shapefiles are included, as well as the GeoJSON file and the TopoJSON command to convert from GeoJSON to TopoJSON.
